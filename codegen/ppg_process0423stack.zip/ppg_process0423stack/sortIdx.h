/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * sortIdx.h
 *
 * Code generation for function 'sortIdx'
 *
 */

#ifndef SORTIDX_H
#define SORTIDX_H

/* Include files */
#include "ppg_process_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void b_merge(emxArray_int32_T *idx, emxArray_real32_T *x, int offset, int np,
             int nq, emxArray_int32_T *iwork, emxArray_real32_T *xwork);

void merge(emxArray_int32_T *idx, emxArray_real32_T *x, int offset, int np,
           int nq, emxArray_int32_T *iwork, emxArray_real32_T *xwork);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (sortIdx.h) */
